VPOS State Reset Utility - Deployment Instructions
====================================================

Version: 1.0
Date: October 2025
London Drugs x Fujitsu Self-Checkout Management


SYSTEM REQUIREMENTS
-------------------
- Windows 10 or Windows 11 (64-bit)
- .NET 8.0 Runtime (Desktop) or later
- Network access to store self-checkout systems


INSTALLATION
------------
1. Extract all files from the ZIP archive to a folder on your computer
2. Keep all files in the same directory (do not separate them)
3. Ensure you have .NET 8.0 Runtime installed on your machine
   Download from: https://dotnet.microsoft.com/download/dotnet/8.0


RUNNING THE APPLICATION
-----------------------
1. Double-click "RoboStateResetUtility.exe" to launch the application
2. The application will open with a modern, clean interface


HOW TO USE
----------
1. Enter Store Number: Type the store number in the text field (e.g., 101, 102)
2. Search Store: Click the "Search Store" button to scan for self-checkout systems
3. Select Checkouts: Once found, select the checkouts you want to reset
   - Use "Select All" to select all found checkouts
   - Use "Deselect All" to clear all selections
4. Reset Value Toggle: Enable or disable the reset value option using the toggle switch
5. Reset Selected: Click "Reset Selected" to perform the state reset on selected checkouts
6. Activity Log: Monitor the activity log panel for real-time status updates
7. Open Log: Click "Open Log" to view the full application log file


FEATURES
--------
- Modern, minimalist user interface
- Network scanning for store self-checkout systems
- Batch reset operations
- Real-time activity logging
- Progress tracking for operations
- Expandable store/checkout list view


TROUBLESHOOTING
---------------
Q: The application won't start
A: Make sure you have .NET 8.0 Runtime installed. Download from Microsoft's website.

Q: Can't find any checkouts
A: Ensure you're connected to the correct network and have proper network access permissions.

Q: Log file location
A: Log files are stored in the application directory with timestamp filenames.


FILES IN THIS PACKAGE
---------------------
- RoboStateResetUtility.exe       Main application executable
- RoboStateResetUtility.dll       Application library
- CommunityToolkit.Mvvm.dll       MVVM framework dependency
- RoboStateResetUtility.deps.json Dependency configuration
- RoboStateResetUtility.runtimeconfig.json Runtime configuration
- README.txt                       This file


SUPPORT
-------
For technical support or issues, please contact your IT administrator.


NOTES
-----
- This application requires network access to self-checkout systems
- Ensure proper permissions before performing reset operations
- Always monitor the activity log during operations
- Keep backup logs for audit purposes


====================================================
London Drugs IT Department
